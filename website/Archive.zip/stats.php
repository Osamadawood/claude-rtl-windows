<?php
require __DIR__ . '/auth.php';
require_login();
require __DIR__ . '/stats-data.php';

header('X-Robots-Tag: noindex, nofollow');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');

$s = load_stats();
$updated = date('Y-m-d H:i');
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="robots" content="noindex">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="refresh" content="60">
<title>Claude RTL — لوحة التحميلات</title>
<link rel="icon" href="assets/favicon/favicon.ico" sizes="48x48">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/tokens.css">
<link rel="stylesheet" href="assets/stats.css">
</head>
<body class="stats-body">

<nav class="stats-nav">
  <div class="stats-nav-in">
    <a class="stats-brand" href="/">
      <img src="assets/img/logo.svg" width="26" height="26" alt="">
      <span>Claude RTL</span>
    </a>
    <div class="stats-nav-actions">
      <a class="stats-btn" href="stats-export.php">تصدير CSV</a>
      <a class="stats-btn" href="">تحديث</a>
      <a class="stats-btn" href="logout.php">خروج</a>
    </div>
  </div>
</nav>

<main class="stats-wrap">
  <div class="stats-head">
    <div>
      <div class="stats-kicker"><span class="dot"></span> لوحة التحميلات</div>
      <h1>إحصائيات التنزيل</h1>
    </div>
    <div class="stats-meta">
      آخر تحديث: <?=htmlspecialchars($updated)?><br>
      توقيت القاهرة · تحديث تلقائي كل 60 ث<br>
      <?=number_format($s['total'])?> سجل في اللوج
    </div>
  </div>

  <?php if ($s['total'] === 0): ?>
  <div class="stats-panel stats-empty">
    <strong>لا توجد تحميلات بعد</strong>
    <span>أول ما حد ينزّل من /download/ClaudeRTL.dmg هتظهر البيانات هنا.</span>
  </div>
  <?php else: ?>

  <?php if ($s['last']): ?>
  <div class="stats-insight">
    <div class="stats-insight-item">
      <strong>آخر تحميل <?=htmlspecialchars(ago($s['last']['ts']))?></strong>
      <span><?=htmlspecialchars(parseBrowser($s['last']['ua'] ?? ''))?> · <?=htmlspecialchars(parseOs($s['last']['ua'] ?? ''))?> · <?=htmlspecialchars(refHost($s['last']['ref'] ?? ''))?></span>
    </div>
    <div class="stats-insight-item">
      <strong>أعلى يوم (14 يوم): <?=htmlspecialchars($s['peak_day'])?></strong>
      <span><?= (int) ($s['days14'][$s['peak_day']] ?? 0) ?> تحميل</span>
    </div>
    <div class="stats-insight-item">
      <strong><?= (int) $s['mac_pct'] ?>% macOS (30 يوم)</strong>
      <span><?= (int) $s['mac30'] ?> mac · <?= (int) $s['other30'] ?> غير mac</span>
    </div>
  </div>
  <?php endif; ?>

  <div class="stats-grid">
    <div class="stats-card">
      <div class="n"><?= (int) $s['total'] ?></div>
      <div class="l">الإجمالي</div>
    </div>
    <div class="stats-card">
      <div class="n"><?= (int) $s['today'] ?></div>
      <div class="l">النهارده</div>
      <div class="sub <?=htmlspecialchars($s['delta']['class'])?>"><?=htmlspecialchars($s['delta']['text'])?></div>
    </div>
    <div class="stats-card">
      <div class="n"><?= (int) $s['yest'] ?></div>
      <div class="l">إمبارح</div>
      <div class="sub flat"><?= (int) $s['yest_uniq'] ?> فريد</div>
    </div>
    <div class="stats-card">
      <div class="n"><?= (int) $s['week'] ?></div>
      <div class="l">آخر 7 أيام</div>
    </div>
    <div class="stats-card">
      <div class="n"><?= (int) $s['month'] ?></div>
      <div class="l">آخر 30 يوم</div>
    </div>
    <div class="stats-card">
      <div class="n"><?= (int) $s['unique'] ?></div>
      <div class="l">زوّار فريدون</div>
      <div class="sub flat"><?= (int) $s['today_uniq'] ?> النهارده</div>
    </div>
  </div>

  <div class="stats-grid stats-grid--3">
    <div class="stats-card">
      <div class="n"><?=htmlspecialchars((string) $s['avg7'])?></div>
      <div class="l">متوسط يومي (7 أيام)</div>
    </div>
    <div class="stats-card">
      <div class="n"><?=htmlspecialchars((string) $s['avg30'])?></div>
      <div class="l">متوسط يومي (30 يوم)</div>
    </div>
    <div class="stats-card">
      <div class="n"><?= (int) $s['today'] > 0 ? (int) round($s['today'] / max(1, (int) date('G') + 1), 1) : 0 ?></div>
      <div class="l">معدل/ساعة النهارده</div>
    </div>
  </div>

  <div class="stats-panel">
    <h2>التحميلات — آخر 14 يوم</h2>
    <p class="stats-panel-note">مرّر على الأعمدة لرؤية التاريخ الكامل</p>
    <div class="stats-chart">
      <?php foreach ($s['days14'] as $d => $c): ?>
      <div class="bar<?=$d === $s['today_str'] ? ' bar--today' : ''?>" title="<?=htmlspecialchars($d)?>: <?=$c?>">
        <span style="height:<?= (int) round($c / $s['max_day'] * 100) ?>%"></span>
        <em><?=htmlspecialchars(substr($d, 8, 2))?></em>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <?php if ($s['today'] > 0): ?>
  <div class="stats-panel">
    <h2>توزيع ساعات النهارده</h2>
    <p class="stats-panel-note">توقيت القاهرة — <?= (int) $s['today'] ?> تحميل</p>
    <div class="stats-chart stats-chart--hours">
      <?php for ($h = 0; $h < 24; $h++): $c = $s['by_hour'][$h]; ?>
      <div class="bar" title="<?=sprintf('%02d:00', $h)?>: <?=$c?>">
        <span style="height:<?= (int) round($c / $s['max_hour'] * 100) ?>%"></span>
        <em><?= $h % 3 === 0 ? sprintf('%02d', $h) : '' ?></em>
      </div>
      <?php endfor; ?>
    </div>
  </div>
  <?php endif; ?>

  <div class="stats-cols">
    <div class="stats-panel"><h2>المصادر</h2><?=barsHtml($s['refs'])?></div>
    <div class="stats-panel"><h2>نظام التشغيل</h2><?=barsHtml($s['os'])?></div>
    <div class="stats-panel"><h2>المتصفح</h2><?=barsHtml($s['brw'])?></div>
  </div>

  <div class="stats-panel">
    <h2>تفصيل يومي — 14 يوم</h2>
    <div class="stats-table-wrap">
      <table class="stats-table">
        <tr><th>اليوم</th><th>التاريخ</th><th>تحميلات</th><th>فريد (تقريبي)</th></tr>
        <?php
        $dayUniq = [];
        foreach ($s['rows'] as $r) {
            $d = cairoDay($r['ts']);
            $dayUniq[$d][$r['vid'] ?? $r['ts']] = true;
        }
        foreach ($s['daily_table'] as $row):
        ?>
        <tr class="<?=$row['is_today'] ? 'row--today' : ''?>">
          <td><?=htmlspecialchars($row['day'])?><?=$row['is_today'] ? '<span class="tag">اليوم</span>' : ''?></td>
          <td class="pill"><?=htmlspecialchars($row['date'])?></td>
          <td><strong><?= (int) $row['count'] ?></strong></td>
          <td class="muted"><?= count($dayUniq[$row['date']] ?? []) ?></td>
        </tr>
        <?php endforeach; ?>
      </table>
    </div>
  </div>

  <div class="stats-panel">
    <h2>آخر 60 تحميل</h2>
    <div class="stats-table-wrap">
      <table class="stats-table">
        <tr><th>منذ</th><th>الوقت (القاهرة)</th><th>النظام</th><th>المتصفح</th><th>المصدر</th><th>IP</th></tr>
        <?php foreach ($s['recent'] as $r): ?>
        <tr>
          <td class="pill"><?=htmlspecialchars(ago($r['ts']))?></td>
          <td class="pill"><?=htmlspecialchars(fmtCairo($r['ts']))?></td>
          <td><?=htmlspecialchars(parseOs($r['ua'] ?? ''))?></td>
          <td><?=htmlspecialchars(parseBrowser($r['ua'] ?? ''))?></td>
          <td class="muted"><?=htmlspecialchars(refHost($r['ref'] ?? ''))?></td>
          <td class="pill"><?=htmlspecialchars($r['ip'] ?? '')?></td>
        </tr>
        <?php endforeach; ?>
      </table>
    </div>
  </div>

  <?php endif; ?>
</main>
</body>
</html>
